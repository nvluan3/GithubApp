Microsoft Virtual PC 2007 Patch for Windows 8
Made by ProgWare
-------
Steps to install :
- Replace the Virtual PC.exe file on The Microsoft Virtual PC 2007 folder with the new Virtual PC.exe file
- Run Virtual PC 2007

Enjoy !